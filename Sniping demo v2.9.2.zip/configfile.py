import sys

token_address=''
decimals='18'
bnb_amount='0'
speedms='0'
sec_wait='0'
max_slippage='100'
gwei='20'
infura_url='https://bsc-dataseed3.binance.org/'

enableprofitsell='0'
pprofitsell='0'
enable_waiting='0'
liq_before='1'
approvetoken='0'
enable_pricebuying='0'
enable_priceselling='0'
enablesellslippage='0'
onlysell='0'
gasusage='700000'
sellslippage='100'
pricebuy='0'
pricesell='0'
version='2'
selltimesenable='0'
selltimes='1'
buytimes='1'
enablestoploss='0'
enabletokenbuy='0'
ttokenbuy='0'
sstoploss='50'


###Newly added in 2.9###
selfaddedcoin=''
addedurlurl=''
updateinfospeed='2'
approvegwei='20'
coinoption='1'
directly='0'
minliq='1'
###Newly added in 2.9###

addedurl=''
retrywhenerror='0'
getclipboard='0'
my_address = '0x739De68832C0504430c38066aF41F8296B68f4A6'
my_pk = '4b364ab4b6a0d38a7ada8be936cc3b5277759927c0b5151ec5508c417e563a83'


sys.path.append(".")
